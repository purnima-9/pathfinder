import React from 'react'
import Pathfinding from './Pathfinding/Pathfinding'
import './App.css';
function App() {
  return (
    <div className='App'>
      
      
      <Pathfinding/>
    </div>
  )
}

export default App
